function idx = domicilios(a)
    idx = -1;
    while idx <= 0
        idx=random(a);
    end
end
