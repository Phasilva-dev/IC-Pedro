function idx = idade(a)
idx = -1;
while idx < 0
    idx=floor(random(a));
end
end